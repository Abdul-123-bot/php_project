<?php

session_start();

//login related functions here
//Handle the account related session and cookies here
function get_DB(){
	// connect to the database
	$hostname = "localhost";
	$username = "root";
	$password = "";
	$sql = new PDO("mysql:host=$hostname;dbname=project", $username, $password);
	$sql->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
	//ini_set('display_errors', 1);
	//error_reporting(E_ALL);
	//echo ' hello ';
	return $sql;
}
function loginProcess($email, $password){
	$sql=get_DB();
		//echo $password;
		$q=$sql->prepare('SELECT * FROM account WHERE email = ?');
		$q->execute(array($email));
		if($r=$q->fetch()){
			//expected format: $pw=sha1($salt.$plainPW);
			$saltPassword=hash_hmac('sha1',$password, $r['salt']);
			//if(true){throw new Exception($r['password']);}
			//alter($saltPassword);
			echo $r['password'];
			if($saltPassword == $r['password']){ 
				if($r['flag'] == 0){
					$exp = time() + 3600 * 24 * 3; // 3days 
					$token = array( 'em'=>$r['email'], 'exp'=>$exp,'k'=>sha1($exp . $r['salt'] . $r['password'])); 
					// create the cookie, make it HTTP only 
					setcookie('authtoken', json_encode($token), $exp,'','',true,true); 
					// put it also in the session
					$_SESSION['authtoken'] = $token;
					return 1;
				}
				else if($r['flag'] == 1){
					$exp = time() + 3600 * 24 * 3; // 3days 
					$token = array( 'em'=>$r['email'], 'exp'=>$exp,'k'=>sha1($exp . $r['salt'] . $r['password'])); 
					// create the cookie, make it HTTP only 
					setcookie('commontoken', json_encode($token), $exp,'','',true,true); 
					// put it also in the session
					$_SESSION['commontoken'] = $token;
					return 2;
				}
			}
		return 0;
		}
	return 0;
}

function auth(){
	if(!empty($_SESSION['authtoken']))
		return $_SESSION['authtoken']['em'];
	if(!empty($_COOKIE['authtoken'])){
		if($t = json_decode(stripslashes($_COOKIE['authtoken']),true)){
			if (time() > $t['exp'])
				return false; 
			$sql=get_DB();
			$q=$sql->prepare('SELECT * FROM account WHERE email = ?');
			$q->execute(array($t['em']));
			if($r=$q->fetch()){
				$realk=hash_hmac('sha1', $t['exp'].$r['password'], $r['salt']);
				if($realk == $t['k']){
					$_SESSION['authtoken'] = $t;
					return $t['em'];
				}
			}
		}
	}	
	return false;
}
?>