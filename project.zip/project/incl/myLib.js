


String.prototype.escapeHTML = function() {
	return this.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
};
String.prototype.escapeQuotes = function() {
	return this.replace(/"/g,'&quot;').replace(/'/g,'&#39;');
};


window.el = function(A) {
	A = document.getElementById(A);
	if (A) {
		A.hide = function(){this.className = 'hide'};
		A.show = function(){this.className = ''};
	}
	return A;
};


(function(){
	
	var myLib = window.myLib = (window.myLib || {});


	function alertFieldError(el, msg) {
		alert('FieldError: ' + msg);
		el.focus();
		return false
	};
	
	
	var encodeParam = function(obj) {
		var data = [];
		for (var key in obj){
		
			data.push(encodeURIComponent(key) + '=' + encodeURIComponent(obj[key]));
		}
		return data.join('&');
	}
	
	
	var formData = function(form) {
		
		this.data = [];
		for (var i = 0, j = 0, name, el, els = form.elements; el = els[i]; i++) {
			
			if (el.disabled || el.name == '' 
				|| ((el.type == 'radio' || el.type == 'checkbox') && !el.checked))
				continue;
			
			this.append(el.name, el.value);
		}
	};
	
	formData.prototype.toString = function(){
		return this.data.join('&');
	};
	
	formData.prototype.append = function(key, val){
		this.data.push(encodeURIComponent(key) + '=' + encodeURIComponent(val));
	};


	
	myLib.ajax = function(opt) {	
		opt = opt || {};
		var xhr = (window.XMLHttpRequest) 
				? new XMLHttpRequest()                     
				: new ActiveXObject("Microsoft.XMLHTTP"),  
			async = opt.async !== false,
			success = opt.success || null, 
			error = opt.error || function(){alert('AJAX Error: ' + this.status)};
			
		
		xhr.open(opt.method || 'GET', opt.url || '', async);
		
		if (opt.method == 'POST') 
			xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		
		
		if (async)
			xhr.onreadystatechange = function(){
				if (xhr.readyState == 4) {
					var status = xhr.status, response = xhr.responseText;
					if ((status >= 200 && status < 300) || status == 304 || status == 1223) {
						success && success.call(xhr, (response.substr(0,9) == 'while(1);') ? response.substring(9) : response);
					} 
					else if (status >= 500)
					{
						error.call(xhr);
					}
				}
			};
		xhr.onerror = function(){error.call(xhr)};
		
		
		xhr.send(opt.data || null);
		
		!async && callback && callback.call(xhr, xhr.responseText);
	};
	
	myLib.processJSON = function(url, param, successCallback, opt) {
		opt = opt || {};
		opt.url = url || 'admin-process.php';
		opt.method = opt.method || 'GET';
		if (param)
			opt.data = encodeParam(param);
			opt.success = function(json){
			json = JSON.parse(json);
			if (json.success)
				successCallback && successCallback.call(this, json.success);
			else 
				alert('Error: ' + json.failed);
		};
		myLib.ajax(opt);
	};
	myLib.get = function(param, successCallback) {
		param = param || {};
		param.rnd =  new Date().getTime(); 
		myLib.processJSON('admin-process.php?' + encodeParam(param), null, successCallback);
	};
	myLib.post = function(param, successCallback) {
		myLib.processJSON('admin-process.php?rnd=' + new Date().getTime(), param, successCallback, {method:'POST'});
	};

	myLib.validate = function(form) {
		for (var i = 0, p, el, els = form.elements; el = els[i]; i++) {
			if (el.disabled) continue;
			if (el.hasAttribute('required')) {
				if (el.type == 'radio') {
					if (lastEl && lastEl == el.name) 
						continue;
					for (var j = 0, chk = false, lastEl = el.name, choices = form[lastEl],
						choice; choice = choices[j]; j++)
							if (choice.checked) {chk = true; break;}
					if (!chk)
						return alertFieldError(el, 'choose a ' + el.title);
					continue;
				} else if ((el.type == 'checkbox' && !el.checked) || el.value == '') 
					return alertFieldError(el, el.title + ' is required');
			}
			if ((p = el.getAttribute('pattern')) && !new RegExp(p).test(el.value))
			return alertFieldError(el, 'in' + el.title);
		}
		return true;
	};
	
	myLib.submit = function(form, successCallback) {
		myLib.validate(form) && myLib.ajax({
			method: 'POST',
			url: form.getAttribute('action') || 'admin-process.php',
			data: new formData(form).toString(),
			success: function(json){
				json = JSON.parse(json);
				if (json.success)
					successCallback && successCallback.call(this, json.success);
				else 
					alert('Error: ' + json.failed);
			}
		});
		return false;
	};

})();